client.subscribe("garden/cmd/1/1");
client.subscribe("garden/cmd/1/2");
client.subscribe("garden/cmd/1/3");
client.subscribe("garden/cmd/1/4");
client.subscribe("garden/cmd/2/1");
client.subscribe("garden/cmd/2/2");
client.subscribe("garden/cmd/2/3");
client.subscribe("garden/cmd/2/4");